package com.cg.media.bean;

import java.sql.Date;

public class Composer_Song_Assoc 
{

	private int composer_Id;
	private String composer_Name;
	private int song_id;
	private String song_name;
	private int Created_by;
	private Date Created_on;
	private int Updated_by;
	private Date Updated_on;
	
	public int getComposer_Id()
	{
		return composer_Id;
	}
	public void setComposer_Id(int composer_Id) 
	{
		this.composer_Id = composer_Id;
	}
	public int getSong_id() 
	{
		return song_id;
	}
	public void setSong_id(int song_id)
	{
		this.song_id = song_id;
	}
	public int getCreated_by() 
	{
		return Created_by;
	}
	public void setCreated_by(int created_by) 
	{
		Created_by = created_by;
	}
	public Date getCreated_on() 
	{
		return Created_on;
	}
	public void setCreated_on(Date created_on) 
	{
		Created_on = created_on;
	}
	public int getUpdated_by()
	{
		return Updated_by;
	}
	public void setUpdated_by(int updated_by) 
	{
		Updated_by = updated_by;
	}
	public Date getUpdated_on() 
	
	{
		return Updated_on;
	}
	public void setUpdated_on(Date updated_on) 
	{
		Updated_on = updated_on;
	}
	public String getComposer_Name() {
		return composer_Name;
	}
	public void setComposer_Name(String composer_Name) {
		this.composer_Name = composer_Name;
	}
	

	public String getSong_name() {
		return song_name;
	}
	public void setSong_name(String song_name) {
		this.song_name = song_name;
	}
	public Composer_Song_Assoc()
	{
		super();
		
	}
	public Composer_Song_Assoc(int composer_Id, String composer_Name,
			int song_id, String song_name, int created_by, Date created_on,
			int updated_by, Date updated_on) {
		super();
		this.composer_Id = composer_Id;
		this.composer_Name = composer_Name;
		this.song_id = song_id;
		this.song_name = song_name;
		Created_by = created_by;
		Created_on = created_on;
		Updated_by = updated_by;
		Updated_on = updated_on;
	}
	
	@Override
	public String toString()
	{
		return "Composer_Song_Assoc [composer_Id=" + composer_Id
				+ ", composer_Name=" + composer_Name + ", song_id=" + song_id
				+ ", song_name=" + song_name + ", Created_by=" + Created_by
				+ ", Created_on=" + Created_on + ", Updated_by=" + Updated_by
				+ ", Updated_on=" + Updated_on + "]";
	}

	
	
	
	
	
	
	
}
