package com.cg.media.bean;

public class User_Master
{
	private int userId;
	private String UserPwd;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserPwd() {
		return UserPwd;
	}
	public void setUserPwd(String userPwd) {
		UserPwd = userPwd;
	}
	public User_Master() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User_Master(int userId, String userPwd) {
		super();
		this.userId = userId;
		UserPwd = userPwd;
	}
	
	
	
}
